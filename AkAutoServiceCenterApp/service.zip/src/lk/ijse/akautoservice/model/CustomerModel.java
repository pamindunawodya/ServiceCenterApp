package lk.ijse.akautoservice.model;


import lk.ijse.akautoservice.to.Customer;
import lk.ijse.akautoservice.util.CrudUtil;

import java.sql.ResultSet;
import java.sql.SQLException;

public class CustomerModel {
    public static boolean save(Customer customer) throws SQLException, ClassNotFoundException {


        return CrudUtil.execute("INSERT INTO Customer VALUES(?, ?, ?, ?, ?)",
                customer.getCustomer_id(),
                customer.getCustomer_name(),
                customer.getCustomer_nic(),
                customer.getCustomer_address(),
                customer.getCustomer_mobile()
        );
    }


    public boolean update(Customer customer) throws SQLException, ClassNotFoundException {
        return CrudUtil.execute("UPDATE Customer SET name=?,nic=?,address=?,contact=? WHERE id=?",
                customer.getCustomer_name(), customer.getCustomer_nic(), customer.getCustomer_address(), customer.getCustomer_mobile());

    }

}
