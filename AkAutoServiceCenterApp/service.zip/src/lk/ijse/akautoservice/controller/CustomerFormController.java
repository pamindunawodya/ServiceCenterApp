package lk.ijse.akautoservice.controller;

import javafx.event.ActionEvent;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import lk.ijse.akautoservice.model.CustomerModel;
import lk.ijse.akautoservice.to.Customer;
import lk.ijse.akautoservice.util.CrudUtil;
import lk.ijse.akautoservice.view.tm.CustomerTm;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Set;

public class CustomerFormController {
    public AnchorPane pane;
    public TextField txtName;
    public TextField txtNic;
    public TextField txtAddress;
    public TextField txtMobile;
    public TextField txtId;
    public TextField txtSearch;



    public void saveCustomerOnAction(ActionEvent actionEvent) {
        String customer_id = txtId.getText();
        String customer_name = txtName.getText();
        String customer_nic = txtNic.getText();
        String customer_address = txtAddress.getText();
        String customer_mobile = txtMobile.getText();

        Customer customer = new Customer(customer_id, customer_name, customer_nic, customer_address, customer_mobile);
        try {
            boolean isAdded = CustomerModel.save(customer);
            if (isAdded) {
                new Alert(Alert.AlertType.CONFIRMATION, "Customer Added!").show();
            }
        } catch (SQLException | ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
    }

  /*  public void customerSearchOnAcion(ActionEvent mouseEvent) {
        String customer_id = txtId.getText();
        try {
            Customer customer = CustomerModel.search(customer_id);
            if (customer != null) {
                fillData(customer);
            }
        } catch (SQLException | ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
    }*/

    private void fillData(Customer customer) {
        txtId.setText(customer.getCustomer_id());
        txtName.setText(customer.getCustomer_name());
        txtNic.setText(customer.getCustomer_nic());
        txtAddress.setText(customer.getCustomer_address());
        txtMobile.setText(customer.getCustomer_mobile());

    }

    public void serachCustomerOnAction(ActionEvent actionEvent) {

        }

    public void customerSearchOnAcion(ActionEvent actionEvent) {
    }
}






