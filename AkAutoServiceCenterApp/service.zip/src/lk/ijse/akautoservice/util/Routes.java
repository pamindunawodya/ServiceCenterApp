package lk.ijse.akautoservice.util;

public enum Routes {

    CUSTOMER,RECEPTIONIST_HOME,VEHICLE,RESERVATION_FORM,RECEPTIONIST_Login
}
