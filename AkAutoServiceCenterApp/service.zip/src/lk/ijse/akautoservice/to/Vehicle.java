package lk.ijse.akautoservice.to;

public class Vehicle {
}
